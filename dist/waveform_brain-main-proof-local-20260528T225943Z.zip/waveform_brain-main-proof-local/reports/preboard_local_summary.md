# Local Pre-Board Check Summary

Timestamp UTC: `2026-05-28T22:51:47.359110+00:00`

Overall pass: **True**
File pass: **True**
Check pass: **True**

## Required files

| File | Exists | Size |
|---|---:|---:|
| `rtl/waveform_brain_axi4lite_cdc_top.v` | True | 13113 |
| `rtl/waveform_brain_cdc_wrapper.v` | True | 14071 |
| `rtl/axilite_regfile_full.v` | True | 16344 |
| `rtl/soft_weighting.v` | True | 3989 |
| `rtl/gkp_decoder.v` | True | 9230 |
| `rtl/poly_eval.v` | True | 2713 |
| `constraints/cdc_xpm_wrapper_constraints.xdc` | True | 1308 |
| `scripts/build_gate_cdc.tcl` | True | 2284 |
| `scripts/verify_cdc_constraints.tcl` | True | 3798 |
| `scripts/parse_cdc_report.py` | True | 5409 |
| `scripts/package_cdc_signoff.py` | True | 1286 |
| `scripts/implementation_gate.py` | True | 5233 |
| `scripts/package_vivado_signoff.py` | True | 1665 |
| `docs/PHASE1_SIGNOFF_SHEET.md` | True | 1287 |
| `docs/CDC_HARDENING_V14.md` | True | 1927 |
| `docs/PREBOARD_GATE_V15.md` | True | 1543 |
| `docs/BOARD_READY_TEMPLATE.md` | True | 1062 |

## Checks

| Command | Required | Raw pass | Gate pass |
|---|---:|---:|---:|
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 -m unittest discover -s tests` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/rtl_sanity_check.py` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/audit_rtl_arithmetic.py` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/generate_reciprocal_lut.py` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/generate_gkp_cosim_vectors.py --count 16` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/extract_register_map.py` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/analyze_cdc_crossings.py` | True | True | True |
| `/Users/dawsonblock/.pyenv/versions/3.9.7/bin/python3 scripts/run_gkp_cosim.py --count 16` | True | True | True |

## Next required Vivado gates

- Vivado elaboration
- CDC reports
- Clock interaction report
- Timing summary
- DRC report
- Utilization report
- CDC sign-off package

This local check does not authorize board testing.
