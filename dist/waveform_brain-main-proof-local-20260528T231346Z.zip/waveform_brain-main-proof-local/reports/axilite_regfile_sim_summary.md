# AXI-Lite Register File Simulation Summary

Timestamp UTC: `2026-05-28T23:13:45.967305+00:00`

Pass: **True**
Return code: `0`

## Output tail

```text
rtl/axilite_regfile_full.v:12: warning: timescale for axilite_regfile_full inherited from another file.
sim/tb_axilite_regfile_full.sv:1: ...: The inherited timescale is here.
rtl/axilite_regfile_full.v:151: vvp.tgt sorry: Case unique/unique0 qualities are ignored.
rtl/axilite_regfile_full.v:188: vvp.tgt sorry: Case unique/unique0 qualities are ignored.
rtl/axilite_regfile_full.v:285: vvp.tgt sorry: Case unique/unique0 qualities are ignored.

TB_PASS tb_axilite_regfile_full
sim/tb_axilite_regfile_full.sv:355: $finish called at 445000 (1ps)
```
