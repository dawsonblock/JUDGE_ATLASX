# Safety Monitor Simulation Summary

Timestamp UTC: `2026-05-28T23:13:46.288824+00:00`

Pass: **True**
Return code: `0`

## Output tail

```text
rtl/safety_monitor.v:7: warning: timescale for safety_monitor inherited from another file.
sim/tb_safety_monitor.sv:1: ...: The inherited timescale is here.
rtl/safety_monitor.v:21: sorry: constant selects in always_* processes are not currently supported (all bits will be included).

TB_PASS tb_safety_monitor
```
