# Implementation Gate Summary

Timestamp UTC: `2026-05-28T21:41:31.806100+00:00`

Overall pass: **False**

| Gate | Pass | Detail |
|---|---:|---|
| cdc_critical | False | missing cdc_critical_summary.json |
| cdc_cell_match | False | missing cdc_cell_match_summary.md |
| timing | False | missing timing_summary.rpt |
| drc | False | missing drc.rpt |

Board testing is blocked unless every gate passes.
